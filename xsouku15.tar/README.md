#Autor: Martin Soukup xsouku15
##Vytvořeno: 20.11.2023
##Popis: Klient a server pro přenos souborů pomocí TFTP.
###Omezení: Server je omezen na připojení pouze jednoho klienta. Není implementován mód netascii. Nezdařilo se implementovat SIGINT.